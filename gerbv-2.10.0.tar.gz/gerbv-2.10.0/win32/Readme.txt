# $Id$
#

This is the windows port of Gerbv, the free open source RS274-X, NC/drill
and xy (centroid) file viewer.

Please visit http://gerbv.geda-project.org for more information about Gerbv.

The windows port makes use of GTK+ for windows.   Please visit 
http://www.gtk.org for more information about GTK.  Without all the hard
work of the GTK+ authors, Gerbv would not exist in its current form.

The windows installer was created with NSIS.  Please visit
http://nsis.sourceforge.net for more information about NSIS.

