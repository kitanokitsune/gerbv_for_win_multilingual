#!/bin/bash

set -e

mingw64-configure				\
	--disable-debug				\
	--disable-update-desktop-database	\

