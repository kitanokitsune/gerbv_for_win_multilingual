#!/bin/bash

set -e

.mc/package-linux.sh 'Ubuntu 22.04'

