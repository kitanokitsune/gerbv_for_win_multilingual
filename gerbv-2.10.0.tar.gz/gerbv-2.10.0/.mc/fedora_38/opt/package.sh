#!/bin/bash

set -e

.mc/package-linux.sh 'Fedora 38'

