#!/bin/bash

set -e

./configure					\
	--disable-debug				\
	--enable-dxf				\
	--disable-update-desktop-database	\

