This is an example from Joachim Jansen (EKF Elektronik GmbH Industrial 
Computers & Information Technology) who kindly sent this files to 
point out some problems in gerbv. They were the first example I had seen
on "omit trailing zeros", which gerbv parsed but silently ignored due to
laziness. 

$Id$
