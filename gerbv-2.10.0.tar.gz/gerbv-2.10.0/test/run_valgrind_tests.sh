#!/bin/sh
./run_tests.sh --valgrind \
               example_cslk \
               out-of-bounds-drill-tool \
               example_am_test \
               parse_aperture_strtok
